from django.shortcuts import render, redirect #se lo importa al render e redirect
from django.http import HttpResponse
from django.contrib.auth.decorators import login_required

from .forms import FormularioProducto

from app.modelo.models import Producto

from django.template import Library
register = Library()
 
@login_required
def principal(request):
	lista = Producto.objects.all()
	context = {
		'Lista': lista,
	}
	return render(request, 'productos/principal_producto.html',context) 
	# contex -> para enviarle variables en el render
	#return HttpResponsive('Es el index del Producto')

def crear(request):
	formulario = FormularioProducto(request.POST) #creamos un objeto FormularioProducto() para poder llamarlo
	if request.method == 'POST': #si el metodo es post sigue..->
		if formulario.is_valid():
			datos = formulario.cleaned_data # cleaned_data -> datos tendra toda la lista de entadas del formulario(nombres,apell.etc)
			producto = Producto() #creamos un Objeto de la clase Producto
			producto.idProducto = datos.get('idProducto')
			producto.nombre = datos.get('nombre')
			producto.marca = datos.get('marca')
			producto.empresa = datos.get('empresa')
			producto.pais = datos.get('pais')
			producto.fechaProduccion = datos.get('fechaProduccion')
			producto.save()
			return redirect(principal)

	context = { #indice : valor -> en el html el formulario se llamará 'f'
		'f': formulario
	}
	return render(request, 'productos/crear_producto.html', context)
	#return HttpResponse('Es la interfaz de crear un Producto')



# def modificar(request):
# 	dni = request.GET['cedula'] # -> obtengo con la peticion "GET" el parametro de una URL
# 	Producto = Producto.objects.get(cedula = dni) #cedula es el atributo del Producto y dni es el valor	if request.method == 'POST'
# 	if request.method == 'POST':
# 		formulario = FormularioProducto(request.POST, instance = Producto)  #creamos una instancia dentro de FormularioProducto()
# 		if formulario.is_valid():
# 			datos = formulario.cleaned_data
# 			Producto.apellidoPaterno = datos.get('apellidoPaterno')
# 			Producto.apellidoMaterno = datos.get('apellidoMaterno')
# 			Producto.nombres = datos.get('nombres')
# 			Producto.fechaNacimiento = datos.get('fechaNacimiento')
# 			Producto.genero = datos.get('genero')
# 			Producto.estadoCivil = datos.get('estadoCivil')
# 			Producto.correo = datos.get('correo')
# 			Producto.celular = datos.get('celular')
# 			Producto.direccion = datos.get('direccion')
# 			Producto.save()
# 			return redirect(principal)
# 	else:
# 		formulario = FormularioProducto(instance = Producto)
# 	context = {
# 		'f': formulario
# 	}
# 	return render(request, 'Productos/modificar_Productos.html', context)
# 	#return HttpResponse('Es la interfaz de modificar un Producto')





