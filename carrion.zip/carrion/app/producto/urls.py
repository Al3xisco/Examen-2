from django.urls import path

from . import views

urlpatterns = [
	path('', views.principal, name='producto'),
	path('crear', views.crear), #crear que va a views /// "crear" -> se puede poner cualquier nombre de dominio
	#path('modificar', views.modificar),
	#path('eliminar', views.eliminar),
]
