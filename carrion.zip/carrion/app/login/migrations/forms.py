from django import forms
from app.modelo.models import Cliente

class FormularioLogin(forms.Form): 
	#El formulario va a ser de tipo From
	username = forms.CharField()
	password = forms.CharField(widget = forms.PasswordInput())
