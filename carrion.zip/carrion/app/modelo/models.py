
from django.db import models
from django.contrib.auth import get_user_model
from django.core.validators import MaxValueValidator

#Create your model

class Producto(models.Model):
	listaMarcas = (
			('c','Cafrilosa'),
			('l','leunutrit'),
		)


	idProducto = models.CharField('idProducto', max_length = 10, unique = True)
	nombre = models.CharField('Nombre', max_length = 25, blank=False, null=False)
	marca = models.CharField(max_length = 10, choices=listaMarcas, default ='c')
	empresa = models.CharField('Empresa', max_length = 25, blank=False, null=False)
	pais = models.TextField(default='Direccion')
	fechaProduccion = models.DateField()

	# def getNombresCompletos(self):
	# 	cadena = '{0} {1} {2}'
	# 	return cadena.format(self.nombre, self.marca, self.empresa)

	# def __srt__(self):
	# 	return idProducto

