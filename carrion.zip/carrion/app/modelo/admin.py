from django.contrib import admin
from .models import Producto #importamos desde cliente cliente.py
# Register your models here.

class AdminProducto(admin.ModelAdmin):
	list_display = ["idProducto", "nombre", "marca", "empresa",
		"pais", "fechaProduccion"]
	list_editable = ["nombre", "pais", "fechaProduccion"]
	list_filter = ["idProducto", "nombre", "marca", "empresa",
		"pais", "fechaProduccion"]

	class Meta:
		model = Producto

admin.site.register(Producto, AdminProducto)

